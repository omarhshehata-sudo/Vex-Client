package com.vexclient.client.mc.gui;

import com.vexclient.client.core.VexTheme;
import com.vexclient.config.ConfigManager;
import com.vexclient.config.VexClientConfigData;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/**
 * Thin settings shell with category tabs — grows alongside future QoL modules.
 *
 * ESC closes while playing; reopen with Right Shift via {@link com.vexclient.client.VexClientClient}.
 */
public class VexMenuScreen extends class_437 {
	private enum Tab {
		HUD,
		PERFORMANCE,
		SETTINGS
	}

	private static final int PANEL_W = 320;
	private static final int PANEL_H = 220;

	private Tab tab = Tab.HUD;

	private class_4185 tabHudButton;
	private class_4185 tabPerfButton;
	private class_4185 tabSettingsButton;

	private class_4185 fpsToggle;
	private class_4185 cpsToggle;
	private class_4185 coordsToggle;

	public VexMenuScreen() {
		super(class_2561.method_43471("vexclient.screen.menu.title"));
	}

	private void applyTabLabels() {
		tabHudButton.method_25355(Tab.HUD.equals(tab)
				? class_2561.method_43471("vexclient.screen.menu.tabs.hud_selected")
				: class_2561.method_43471("vexclient.screen.menu.tabs.hud"));
		tabPerfButton.method_25355(Tab.PERFORMANCE.equals(tab)
				? class_2561.method_43471("vexclient.screen.menu.tabs.performance_selected")
				: class_2561.method_43471("vexclient.screen.menu.tabs.performance"));
		tabSettingsButton.method_25355(Tab.SETTINGS.equals(tab)
				? class_2561.method_43471("vexclient.screen.menu.tabs.settings_selected")
				: class_2561.method_43471("vexclient.screen.menu.tabs.settings"));
	}

	private void rebuildHudTexts() {
		VexClientConfigData cfg = ConfigManager.INSTANCE.get();
		this.fpsToggle.method_25355(class_2561.method_43471(
				cfg.hudFpsCounter ? "vexclient.screen.menu.toggle.fps.on" : "vexclient.screen.menu.toggle.fps.off"));
		this.cpsToggle.method_25355(class_2561.method_43471(
				cfg.hudCpsCounter ? "vexclient.screen.menu.toggle.cps.on" : "vexclient.screen.menu.toggle.cps.off"));
		this.coordsToggle.method_25355(class_2561.method_43471(
				cfg.hudCoordinates ? "vexclient.screen.menu.toggle.coords.on" : "vexclient.screen.menu.toggle.coords.off"));
	}

	private void refreshVisibility() {
		boolean hudTab = Tab.HUD.equals(tab);
		this.fpsToggle.field_22764 = hudTab;
		this.cpsToggle.field_22764 = hudTab;
		this.coordsToggle.field_22764 = hudTab;
		this.applyTabLabels();
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		ConfigManager.INSTANCE.ensureLoaded();

		int px = this.field_22789 / 2 - PANEL_W / 2;
		int py = this.field_22790 / 2 - PANEL_H / 2;

		int btnH = 20;
		int tabGap = 6;
		int tabW = (PANEL_W - 16 - tabGap * 2) / 3;
		int tabY = py + 42;

		this.tabHudButton = class_4185.method_46430(class_2561.method_43473(), btn -> {
			tab = Tab.HUD;
			refreshVisibility();
		}).method_46434(px + 12, tabY, tabW, btnH).method_46431();

		this.tabPerfButton = class_4185.method_46430(class_2561.method_43473(), btn -> {
			tab = Tab.PERFORMANCE;
			refreshVisibility();
		}).method_46434(px + 12 + tabW + tabGap, tabY, tabW, btnH).method_46431();

		this.tabSettingsButton = class_4185.method_46430(class_2561.method_43473(), btn -> {
			tab = Tab.SETTINGS;
			refreshVisibility();
		}).method_46434(px + 12 + (tabW + tabGap) * 2, tabY, tabW, btnH).method_46431();

		int rowStartY = tabY + btnH + 18;
		int rowW = PANEL_W - 24;

		this.fpsToggle = class_4185.method_46430(class_2561.method_43473(), btn -> {
			ConfigManager.INSTANCE.update(cfg -> cfg.hudFpsCounter = !cfg.hudFpsCounter);
			rebuildHudTexts();
		}).method_46434(px + 14, rowStartY + 2, rowW, btnH).method_46431();

		this.cpsToggle = class_4185.method_46430(class_2561.method_43473(), btn -> {
			ConfigManager.INSTANCE.update(cfg -> cfg.hudCpsCounter = !cfg.hudCpsCounter);
			rebuildHudTexts();
		}).method_46434(px + 14, rowStartY + 2 + (btnH + 6), rowW, btnH).method_46431();

		this.coordsToggle = class_4185.method_46430(class_2561.method_43473(), btn -> {
			ConfigManager.INSTANCE.update(cfg -> cfg.hudCoordinates = !cfg.hudCoordinates);
			rebuildHudTexts();
		}).method_46434(px + 14, rowStartY + 2 + (btnH + 6) * 2, rowW, btnH).method_46431();

		this.method_37063(this.tabHudButton);
		this.method_37063(this.tabPerfButton);
		this.method_37063(this.tabSettingsButton);
		this.method_37063(this.fpsToggle);
		this.method_37063(this.cpsToggle);
		this.method_37063(this.coordsToggle);

		rebuildHudTexts();
		refreshVisibility();
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		this.method_25420(context, mouseX, mouseY, delta);

		int px = this.field_22789 / 2 - PANEL_W / 2;
		int py = this.field_22790 / 2 - PANEL_H / 2;

		fillOutline(context, px, py, PANEL_W, PANEL_H, VexTheme.PANEL_BACKGROUND, VexTheme.BORDER_PURPLE);

		context.method_27534(
				this.field_22793,
				class_2561.method_43471("vexclient.screen.menu.title"),
				this.field_22789 / 2,
				py + 14,
				VexTheme.TEXT_WHITE);

		context.method_25292(px + 10, px + PANEL_W - 10, py + 32, VexTheme.BORDER_PURPLE);

		super.method_25394(context, mouseX, mouseY, delta);

		renderTabBodies(context, px, py);

		context.method_27534(
				this.field_22793,
				class_2561.method_43471("vexclient.screen.menu.press_esc_close"),
				this.field_22789 / 2,
				py + PANEL_H - 18,
				0xFF9AA0B8);
	}

	private void renderTabBodies(class_332 ctx, int px, int py) {
		int inset = 14;
		int textMaxW = PANEL_W - inset * 2;
		int bodyTop = py + 42 + 20 + 12;
		int left = px + inset;

		if (Tab.PERFORMANCE.equals(tab)) {
			String paragraph = class_1074.method_4662("vexclient.screen.performance.paragraph");
			drawWrappedPlain(ctx, left, bodyTop + 6, textMaxW, paragraph, VexTheme.TEXT_WHITE);

			ctx.method_51439(
					this.field_22793,
					class_2561.method_43471("vexclient.screen.performance.placeholder_header"),
					left,
					py + PANEL_H - 110,
					VexTheme.ACCENT_PURPLE,
					false);

			String[] todos = new String[] {
					"* TODO(alpha+): optional FPS pacing hints (informational reminders only — no cheats).",
					"* TODO(alpha+): frame-time overlay hooks reserved for profiler-style debugging overlays.",
					"* TODO(alpha+): future render-distance / simulation-distance tips for low-memory installs."
			};
			int yTodo = py + PANEL_H - 92;
			for (String line : todos) {
				ctx.method_51439(this.field_22793, class_2561.method_43470(line), left, yTodo, 0xFF8492B5, false);
				yTodo += 12;
			}
			return;
		}

		if (Tab.SETTINGS.equals(tab)) {
			ctx.method_51439(
					this.field_22793,
					class_2561.method_43471("vexclient.screen.settings.config_path.header"),
					left,
					bodyTop + 6,
					VexTheme.ACCENT_PURPLE,
					false);

			String pathShown = shorten(ConfigManager.INSTANCE.getConfigPath().toAbsolutePath().toString(), 58);
			ctx.method_51439(this.field_22793, class_2561.method_43470(pathShown), left, bodyTop + 22, VexTheme.TEXT_WHITE, false);

			String hint = class_1074.method_4662("vexclient.screen.settings.hint");
			drawWrappedPlain(ctx, left, bodyTop + 42, textMaxW, hint, 0xFFA8B5D6);
		}
	}

	/**
	 * Manual wrap for alpha: breaks on spaces and hard newlines. Good enough for short tutorial copy.
	 */
	private void drawWrappedPlain(class_332 ctx, int left, int top, int maxWidth, String body, int color) {
		String normalized = body.replace("\r\n", "\n");
		int lineHeight = Math.max(this.field_22793.field_2000 + 2, 12);
		int y = top;

		for (String paragraph : normalized.split("\n")) {
			String trimmed = paragraph.strip();
			if (trimmed.isEmpty()) {
				y += lineHeight;
				continue;
			}

			class_2561 literal = class_2561.method_43470(trimmed);
			for (class_5481 line : this.field_22793.method_1728(literal, maxWidth)) {
				ctx.method_51433(this.field_22793, asPlainString(line), left, y, color, false);
				y += lineHeight;
			}
		}
	}

	private static String asPlainString(class_5481 ot) {
		StringBuilder sb = new StringBuilder();
		ot.accept((index, style, codePoint) -> {
			sb.appendCodePoint(codePoint);
			return true;
		});
		return sb.toString();
	}

	private static String shorten(String raw, int maxChars) {
		if (raw.length() <= maxChars) {
			return raw;
		}
		int keep = Math.max(16, maxChars - 6);
		int lhs = keep / 2;
		int rhs = keep - lhs;
		return raw.substring(0, lhs) + " … " + raw.substring(raw.length() - rhs);
	}

	private static void fillOutline(class_332 context, int x, int y, int w, int h, int fill, int border) {
		context.method_25294(x, y, x + w, y + h, fill);
		int t = 1;
		context.method_25294(x, y, x + w, y + t, border);
		context.method_25294(x, y + h - t, x + w, y + h, border);
		context.method_25294(x, y, x + t, y + h, border);
		context.method_25294(x + w - t, y, x + w, y + h, border);
	}
}
