package com.vexclient.client.mc.gui.login;

import com.vexclient.client.core.VexTheme;
import com.vexclient.client.core.auth.MicrosoftAuthException;
import com.vexclient.client.mc.auth.MicrosoftAuthManager;
import com.vexclient.client.core.auth.model.MinecraftAccount;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Vex Client account screen.
 *
 * <p>This uses official Microsoft OAuth in the user's browser (Authorization Code + PKCE).
 * No passwords are collected or stored.
 */
public final class LoginScreen extends class_437 {
	private static final int PANEL_W = 360;
	private static final int PANEL_H = 210;

	private class_4185 signIn;
	private class_4185 signOut;
	private class_4185 back;

	private String statusLine = "";
	private CompletableFuture<?> inFlight;

	public LoginScreen(class_437 parent) {
		super(class_2561.method_43471("vexclient.screen.login.title"));
		this.parent = parent;
	}

	private final class_437 parent;

	@Override
	protected void method_25426() {
		super.method_25426();

		int px = this.field_22789 / 2 - PANEL_W / 2;
		int py = this.field_22790 / 2 - PANEL_H / 2;

		int bw = PANEL_W - 24;
		int bh = 20;

		this.signIn = class_4185.method_46430(class_2561.method_43471("vexclient.screen.login.sign_in"), btn -> {
			startLogin();
		}).method_46434(px + 12, py + 92, bw, bh).method_46431();

		this.signOut = class_4185.method_46430(class_2561.method_43471("vexclient.screen.login.sign_out"), btn -> {
			MicrosoftAuthManager.INSTANCE.signOut();
			statusLine = class_1074.method_4662("vexclient.screen.login.signed_out");
			rebuild();
		}).method_46434(px + 12, py + 92, bw, bh).method_46431();

		this.back = class_4185.method_46430(class_2561.method_43471("gui.back"), btn -> {
			this.method_25419();
		}).method_46434(px + 12, py + PANEL_H - 34, bw, bh).method_46431();

		this.method_37063(this.signIn);
		this.method_37063(this.signOut);
		this.method_37063(this.back);

		rebuild();
	}

	private void rebuild() {
		Optional<MinecraftAccount> acc = MicrosoftAuthManager.INSTANCE.getActiveAccount();
		boolean signedIn = acc.isPresent();

		this.signIn.field_22764 = !signedIn;
		this.signIn.field_22763 = inFlight == null;

		this.signOut.field_22764 = signedIn;
		this.signOut.field_22763 = inFlight == null;
	}

	private void startLogin() {
		if (inFlight != null) {
			return;
		}

		statusLine = class_1074.method_4662("vexclient.screen.login.waiting_browser");
		rebuild();

		inFlight = MicrosoftAuthManager.INSTANCE.signInWithMicrosoftInteractive()
				.whenComplete((account, throwable) -> {
					inFlight = null;

					if (throwable == null && account != null) {
						statusLine = class_1074.method_4662("vexclient.screen.login.success", account.username());
					} else {
						Throwable root = throwable;
						while (root.getCause() != null) {
							root = root.getCause();
						}

						if (root instanceof MicrosoftAuthException mae) {
							switch (mae.error()) {
								case MICROSOFT_LOGIN_FAILED -> statusLine = class_1074.method_4662("vexclient.screen.login.error.microsoft");
								case XBOX_AUTH_FAILED -> statusLine = class_1074.method_4662("vexclient.screen.login.error.xbox");
								case MINECRAFT_JAVA_NOT_OWNED -> statusLine = class_1074.method_4662("vexclient.screen.login.error.not_owned");
								case TOKEN_EXPIRED -> statusLine = class_1074.method_4662("vexclient.screen.login.error.expired");
							}
						} else {
							statusLine = class_1074.method_4662("vexclient.screen.login.error.microsoft");
						}
					}

					if (this.field_22787 != null) {
						this.field_22787.execute(this::rebuild);
					}
				});
	}

	@Override
	public void method_25419() {
		if (this.field_22787 != null) {
			this.field_22787.method_1507(parent);
		}
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		this.method_25420(context, mouseX, mouseY, delta);

		int px = this.field_22789 / 2 - PANEL_W / 2;
		int py = this.field_22790 / 2 - PANEL_H / 2;

		fillOutline(context, px, py, PANEL_W, PANEL_H, VexTheme.PANEL_BACKGROUND, VexTheme.BORDER_PURPLE);

		context.method_27534(
				this.field_22793,
				class_2561.method_43471("vexclient.screen.login.title"),
				this.field_22789 / 2,
				py + 14,
				VexTheme.TEXT_WHITE);

		Optional<MinecraftAccount> acc = MicrosoftAuthManager.INSTANCE.getActiveAccount();
		if (acc.isPresent()) {
			MinecraftAccount a = acc.get();
			context.method_51439(this.field_22793, class_2561.method_43471("vexclient.screen.login.signed_in_as"), px + 14, py + 44, VexTheme.ACCENT_PURPLE, false);
			context.method_51439(this.field_22793, class_2561.method_43470(a.username()), px + 14, py + 58, VexTheme.TEXT_WHITE, false);
			context.method_51439(this.field_22793, class_2561.method_43470(a.uuid().toString()), px + 14, py + 72, 0xFF9AA0B8, false);
		} else {
			context.method_51439(this.field_22793, class_2561.method_43471("vexclient.screen.login.not_signed_in"), px + 14, py + 52, 0xFF9AA0B8, false);
		}

		if (statusLine != null && !statusLine.isBlank()) {
			context.method_51439(this.field_22793, class_2561.method_43470(statusLine), px + 14, py + 118, 0xFFB2B8CE, false);
		}

		super.method_25394(context, mouseX, mouseY, delta);
	}

	private static void fillOutline(class_332 context, int x, int y, int w, int h, int fill, int border) {
		context.method_25294(x, y, x + w, y + h, fill);
		int t = 1;
		context.method_25294(x, y, x + w, y + t, border);
		context.method_25294(x, y + h - t, x + w, y + h, border);
		context.method_25294(x, y, x + t, y + h, border);
		context.method_25294(x + w - t, y, x + w, y + h, border);
	}
}
