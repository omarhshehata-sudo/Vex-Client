package com.vexclient.client.mc.title;

import com.vexclient.client.core.VexTheme;
import com.vexclient.client.mc.gui.login.LoginScreen;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_442;

/**
 * Lightweight title-screen overlay for Vex branding. Purely cosmetic; safe for multiplayer.
 */
public final class TitleScreenBranding {
	private TitleScreenBranding() {
	}

	public static void register() {
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (!(screen instanceof class_442)) {
				return;
			}

			// Add a small Vex "Account" entry point on the title screen.
			int w = 110;
			int h = 20;
			int x = scaledWidth - w - 8;
			int y = 8;
			Screens.getButtons(screen).add(
					class_4185.method_46430(class_2561.method_43471("vexclient.title.account_button"), btn -> client.method_1507(new LoginScreen(screen)))
							.method_46434(x, y, w, h)
							.method_46431()
			);

			ScreenEvents.afterRender(screen).register((scr, context, mx, my, tickDelta) -> {
				if (!(scr instanceof class_442 ts)) {
					return;
				}
				renderTitleOverlay(class_310.method_1551(), ts, context);
			});
		});
	}

	private static void renderTitleOverlay(class_310 client, class_442 screen, class_332 ctx) {
		var font = client.field_1772;

		class_2561 headline = class_2561.method_43471("vexclient.title.overlay.headline");
		class_2561 subtitle = class_2561.method_43471("vexclient.title.overlay.subtitle");

		int headlineW = font.method_27525(headline);
		int subW = font.method_27525(subtitle);
		int lineHeight = Math.max(font.field_2000, 9);

		int cx = screen.field_22789 / 2;
		int headlineY = (int) (screen.field_22790 * 0.78f);
		int subtitleY = headlineY + lineHeight + 3;

		int padX = 10;
		int padY = 6;
		int boxW = Math.max(headlineW, subW) + padX * 2;
		int boxH = padY * 2 + lineHeight * 2 + 3;

		int left = cx - boxW / 2;
		int top = headlineY - padY;

		fillOutline(ctx, left, top, boxW, boxH, VexTheme.PANEL_BACKGROUND, VexTheme.BORDER_PURPLE);

		int hx = cx - headlineW / 2;
		drawShadowTwoTone(ctx, font, headline.getString(), hx, headlineY, VexTheme.ACCENT_PURPLE, VexTheme.SHADOW_DEEP_PURPLE);

		int sx = cx - subW / 2;
		drawShadowTwoTone(ctx, font, subtitle.getString(), sx, subtitleY, VexTheme.TEXT_WHITE, VexTheme.SHADOW_DEEP_PURPLE);
	}

	private static void drawShadowTwoTone(class_332 ctx, net.minecraft.class_327 font, String txt, int x, int y, int argbFore, int argbShadow) {
		ctx.method_51433(font, txt, x + 1, y + 1, argbShadow, false);
		ctx.method_51433(font, txt, x, y, argbFore, false);
	}

	private static void fillOutline(class_332 context, int x, int y, int w, int h, int fill, int border) {
		context.method_25294(x, y, x + w, y + h, fill);
		int t = 1;
		context.method_25294(x, y, x + w, y + t, border);
		context.method_25294(x, y + h - t, x + w, y + h, border);
		context.method_25294(x, y, x + t, y + h, border);
		context.method_25294(x + w - t, y, x + w, y + h, border);
	}
}
