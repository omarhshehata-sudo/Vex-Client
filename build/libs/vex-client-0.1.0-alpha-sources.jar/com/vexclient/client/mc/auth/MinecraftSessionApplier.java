package com.vexclient.client.mc.auth;

import com.vexclient.client.core.auth.model.MinecraftAccount;
import com.vexclient.client.mc.mixin.MinecraftAccessor;
import net.minecraft.class_310;
import net.minecraft.class_320;

/**
 * Minecraft 1.21.4 specific integration: apply an authenticated token into the in-memory {@link class_320}.
 */
public final class MinecraftSessionApplier {
	private MinecraftSessionApplier() {
	}

	public static void apply(MinecraftAccount account) {
		try {
			class_310 client = class_310.method_1551();
			class_320 user = new class_320(
					account.username(),
					account.uuid(),
					account.minecraftAccessToken(),
					java.util.Optional.empty(),
					java.util.Optional.empty(),
					class_320.class_321.field_34962
			);

			((MinecraftAccessor) client).setUser(user);
		} catch (Throwable ignored) {
			// Non-fatal: even if swapping fails, we still keep token cache for future launcher integration.
		}
	}
}
