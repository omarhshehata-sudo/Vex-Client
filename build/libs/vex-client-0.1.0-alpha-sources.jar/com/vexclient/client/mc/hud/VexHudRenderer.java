package com.vexclient.client.mc.hud;

import com.vexclient.VexClient;
import com.vexclient.client.core.VexTheme;
import com.vexclient.client.mc.input.CpsTracker;
import com.vexclient.config.ConfigManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.IdentifiedLayer;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Lightweight overlay renderer for QoL HUD lines (FPS/CPS/coordinates).
 *
 * <p>Registered as a hud layer anchored after subtitles so overlays stay above vanilla HUD clutter.
 *
 * TODO: Split each HUD line into its own tiny class once overlays grow (graphs / draggable HUD stacks ...).
 * TODO: If you introduce many overlays, consolidate behind a registry that maps {@link com.vexclient.module.HudOverlayId} -> renderer.
 */
public final class VexHudRenderer {
	private static final class_2960 HUD_LAYER_ID = class_2960.method_60655(VexClient.MOD_ID, "hud_quality_of_life");

	private VexHudRenderer() {
	}

	public static void registerHudLayer(CpsTracker cpsTracker) {
		HudLayerRegistrationCallback.EVENT.register(drawerWrapper -> drawerWrapper.attachLayerAfter(
				IdentifiedLayer.SUBTITLES,
				HUD_LAYER_ID,
				(context, tickCounter) -> render(context, cpsTracker)
		));
	}

	private static void render(class_332 context, CpsTracker cpsTracker) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1690.field_1842) {
			return;
		}

		var cfg = ConfigManager.INSTANCE.get();
		if (!cfg.hudFpsCounter && !cfg.hudCpsCounter && !cfg.hudCoordinates) {
			return;
		}

		class_327 tr = client.field_1772;

		java.util.ArrayList<HudLine> lines = new java.util.ArrayList<>();
		if (cfg.hudFpsCounter) {
			lines.add(new HudLine("FPS", Integer.toString(client.method_47599())));
		}
		if (cfg.hudCpsCounter) {
			lines.add(new HudLine("CPS", Integer.toString(cpsTracker.clicksPerSecond())));
		}
		if (cfg.hudCoordinates) {
			var bp = client.field_1724.method_24515();
			lines.add(new HudLine(
					"XYZ",
					bp.method_10263() + " / " + bp.method_10264() + " / " + bp.method_10260()
			));
		}

		if (lines.isEmpty()) {
			return;
		}

		int lineHeight = Math.max(tr.field_2000 + 1, 10);
		int padX = 6;
		int padY = 4;

		int maxWidth = 0;
		for (HudLine line : lines) {
			int w = tr.method_1727(line.label());
			if (!line.value().isEmpty()) {
				w += tr.method_1727(" " + line.value());
			}
			maxWidth = Math.max(maxWidth, w);
		}

		int margin = 6;
		int boxW = maxWidth + padX * 2;
		int boxH = padY * 2 + lineHeight * lines.size();
		int left = margin;
		int scaledHeight = client.method_22683().method_4502();

		int top = scaledHeight - margin - boxH;

		fillOutline(context, left, top, boxW, boxH, VexTheme.PANEL_BACKGROUND, VexTheme.BORDER_PURPLE);

		int ty = top + padY + 1;
		for (int i = 0; i < lines.size(); i++) {
			renderLine(context, tr, left + padX, ty + i * lineHeight, lines.get(i));
		}
	}

	private static void renderLine(class_332 ctx, class_327 tr, int x, int y, HudLine line) {
		int cursor = x;

		ctx.method_51433(tr, line.label(), cursor + 1, y + 1, VexTheme.SHADOW_DEEP_PURPLE, false);
		ctx.method_51433(tr, line.label(), cursor, y, VexTheme.ACCENT_PURPLE, false);
		cursor += tr.method_1727(line.label());

		if (!line.value().isEmpty()) {
			String gapPlusValue = " " + line.value();
			ctx.method_51433(tr, gapPlusValue, cursor + 1, y + 1, VexTheme.SHADOW_DEEP_PURPLE, false);
			ctx.method_51433(tr, gapPlusValue, cursor, y, VexTheme.TEXT_WHITE, false);
		}
	}

	private record HudLine(String label, String value) {
	}

	private static void fillOutline(class_332 context, int x, int y, int w, int h, int fill, int border) {
		context.method_25294(x, y, x + w, y + h, fill);
		int t = 1;
		context.method_25294(x, y, x + w, y + t, border);
		context.method_25294(x, y + h - t, x + w, y + h, border);
		context.method_25294(x, y, x + t, y + h, border);
		context.method_25294(x + w - t, y, x + w, y + h, border);
	}
}
