package com.vexclient.client.mc.input;

import org.lwjgl.glfw.GLFW;
import java.util.ArrayDeque;
import net.minecraft.class_310;
import net.minecraft.class_408;

/**
 * Tracks physical left-clicks over a rolling 1-second window to estimate CPS.
 *
 * <p>Intentionally scoped to in-world gameplay (no world / pause / hidden HUD) so menu clicking does not spike CPS.
 */
public final class CpsTracker {
	private final ArrayDeque<Long> recentClicksMs = new ArrayDeque<>();
	private boolean leftDown;

	public void tick(class_310 client) {
		if (client.field_1687 == null || client.method_1493()) {
			return;
		}
		if (client.field_1690.field_1842) {
			return;
		}
		if (client.field_1755 != null && !(client.field_1755 instanceof class_408)) {
			return;
		}

		long window = client.method_22683().method_4490();
		boolean down = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

		if (down && !leftDown) {
			long now = System.currentTimeMillis();
			recentClicksMs.addLast(now);

			long cutoff = now - 1_000L;
			while (!recentClicksMs.isEmpty() && recentClicksMs.peekFirst() < cutoff) {
				recentClicksMs.removeFirst();
			}
		}

		leftDown = down;
	}

	public int clicksPerSecond() {
		long now = System.currentTimeMillis();
		long cutoff = now - 1_000L;
		while (!recentClicksMs.isEmpty() && recentClicksMs.peekFirst() < cutoff) {
			recentClicksMs.removeFirst();
		}
		return recentClicksMs.size();
	}
}
