package com.vexclient.client.mc.mixin;

import net.minecraft.class_310;
import net.minecraft.class_320;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Accessor used to apply a newly authenticated {@link class_320} after Microsoft sign-in.
 *
 * <p>TODO(multiversion): field name/type changes between MC versions — verify {@code user} mutability when adding mc-1.21.1 etc.
 */
@Mixin(class_310.class)
public interface MinecraftAccessor {
	@Accessor("user")
	class_320 getUser();

	@Mutable
	@Accessor("user")
	void setUser(class_320 user);
}
